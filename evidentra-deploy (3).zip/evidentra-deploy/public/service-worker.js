// ── Evidentra Care Service Worker ────────────────────────────
// Handles caching, offline support, and background sync
// Version: 1.0.0

const CACHE_NAME = 'evidentra-care-v1';
const STATIC_CACHE = 'evidentra-static-v1';
const API_CACHE = 'evidentra-api-v1';

// Files to cache immediately on install
const PRECACHE_URLS = [
  '/',
  '/index.html',
  '/static/js/main.chunk.js',
  '/static/js/bundle.js',
  '/static/css/main.chunk.css',
  '/manifest.json',
  'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&display=swap',
];

// ── Install — cache essential files ──────────────────────────
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then(cache => {
        console.log('[SW] Pre-caching app shell');
        return cache.addAll(PRECACHE_URLS.map(url => {
          return new Request(url, { mode: 'no-cors' });
        }));
      })
      .then(() => self.skipWaiting())
      .catch(err => {
        console.log('[SW] Pre-cache failed (some resources may not be available offline):', err);
        return self.skipWaiting();
      })
  );
});

// ── Activate — clean old caches ───────────────────────────────
self.addEventListener('activate', event => {
  const currentCaches = [CACHE_NAME, STATIC_CACHE, API_CACHE];
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return cacheNames.filter(name => !currentCaches.includes(name));
      })
      .then(cachesToDelete => {
        return Promise.all(cachesToDelete.map(cache => {
          console.log('[SW] Deleting old cache:', cache);
          return caches.delete(cache);
        }));
      })
      .then(() => self.clients.claim())
  );
});

// ── Fetch — serve from cache, fall back to network ───────────
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Skip non-GET requests and browser extensions
  if (request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // API calls — network first, cache fallback
  if (url.hostname.includes('supabase.co') || url.hostname.includes('anthropic.com')) {
    event.respondWith(
      fetch(request)
        .then(response => {
          if (response.ok) {
            const responseClone = response.clone();
            caches.open(API_CACHE).then(cache => cache.put(request, responseClone));
          }
          return response;
        })
        .catch(() => caches.match(request))
    );
    return;
  }

  // Google Fonts — cache first
  if (url.hostname.includes('fonts.googleapis.com') || url.hostname.includes('fonts.gstatic.com')) {
    event.respondWith(
      caches.match(request)
        .then(cached => cached || fetch(request).then(response => {
          const responseClone = response.clone();
          caches.open(STATIC_CACHE).then(cache => cache.put(request, responseClone));
          return response;
        }))
    );
    return;
  }

  // App shell — cache first, network fallback
  event.respondWith(
    caches.match(request)
      .then(cached => {
        if (cached) return cached;
        return fetch(request)
          .then(response => {
            if (!response || response.status !== 200 || response.type === 'opaque') {
              return response;
            }
            const responseClone = response.clone();
            caches.open(STATIC_CACHE).then(cache => cache.put(request, responseClone));
            return response;
          })
          .catch(() => {
            // Offline fallback — return cached index.html for navigation requests
            if (request.mode === 'navigate') {
              return caches.match('/index.html');
            }
          });
      })
  );
});

// ── Background sync — retry failed requests when back online ──
self.addEventListener('sync', event => {
  if (event.tag === 'background-sync') {
    console.log('[SW] Background sync triggered');
  }
});

// ── Push notifications (ready for future use) ─────────────────
self.addEventListener('push', event => {
  if (!event.data) return;
  const data = event.data.json();
  const options = {
    body: data.body || 'You have a new compliance alert',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/icon-72x72.png',
    vibrate: [100, 50, 100],
    data: { url: data.url || '/' },
    actions: [
      { action: 'view', title: 'View', icon: '/icons/icon-72x72.png' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };
  event.waitUntil(
    self.registration.showNotification(
      data.title || 'Evidentra Care',
      options
    )
  );
});

// Handle notification click
self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action === 'view') {
    event.waitUntil(
      clients.openWindow(event.notification.data.url || '/')
    );
  }
});

console.log('[SW] Evidentra Care service worker loaded v1.0.0');
